#define __USE_XOPEN
#define _GNU_SOURCE

#include <stdio.h>

int main(int argc, char const *argv[]) {
    printf("Good luck in this projet!\n");
    return 0;
}
